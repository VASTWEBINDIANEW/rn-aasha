/**
 * PassportPhotoScreen
 *
 * Flow:
 *  1. Camera opens → runs face detection every 300ms automatically
 *  2. No face       → red oval   → "Position your face in the frame"
 *  3. Multiple face → red oval   → "Only one face allowed"
 *  4. Face detected → green oval → Capture button appears
 *  5. User presses Capture → photo taken → crop to passport size
 *  6. Modal shows preview → Retake | Continue
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Platform,
  StatusBar,
  Image as RNImage,
  ActivityIndicator,
  SafeAreaView,
} from 'react-native';
import { Camera, useCameraDevice } from 'react-native-vision-camera';
import FaceDetection from '@react-native-ml-kit/face-detection';
import RNFS from 'react-native-fs';
import { WebView } from 'react-native-webview';

// ─────────────────────────────────────────────
// CONFIG
// ─────────────────────────────────────────────
const DETECT_INTERVAL_MS = 300;   // face detection polling speed
const OUT_W              = 413;   // passport output width  (px)
const OUT_H              = 531;   // passport output height (px)

// ─────────────────────────────────────────────
// SCREEN STATES
// ─────────────────────────────────────────────
const S = {
  IDLE:       'idle',        // camera not ready yet
  NO_FACE:    'no_face',     // 0 faces detected
  MULTI:      'multi',       // 2+ faces detected
  FACE_OK:    'face_ok',     // exactly 1 face — show Capture button
  CAPTURING:  'capturing',   // button pressed, taking photo
  PROCESSING: 'processing',  // cropping image
  DONE:       'done',        // modal visible
};

const HINT = {
  [S.IDLE]:       'Initializing camera...',
  [S.NO_FACE]:    'Position your face inside the oval',
  [S.MULTI]:      'Only one face is allowed',
  [S.FACE_OK]:    'Face detected — press Capture',
  [S.CAPTURING]:  'Hold still...',
  [S.PROCESSING]: 'Processing photo...',
  [S.DONE]:       '',
};

function borderColor(state) {
  if (state === S.NO_FACE || state === S.MULTI)   return '#FF3B30';
  if (state === S.FACE_OK)                         return '#34C759';
  if (state === S.CAPTURING || state === S.PROCESSING) return '#FFD600';
  return '#FFFFFF';
}

// ─────────────────────────────────────────────
// PASSPORT CROP — runs inside a hidden WebView
// ─────────────────────────────────────────────
function buildCropHTML(base64, frame, imgW, imgH) {
  const { left, top, width, height } = frame;

  const padX    = width  * 0.65;
  const padYTop = height * 0.90;
  const padYBot = height * 0.55;

  const cropX = Math.max(0, left - padX);
  const cropY = Math.max(0, top  - padYTop);
  const cropW = Math.min(imgW - cropX, width  + padX * 2);
  const cropH = Math.min(imgH - cropY, height + padYTop + padYBot);

  return `<!DOCTYPE html><html><body style="margin:0;padding:0">
<canvas id="c"></canvas>
<script>
(function(){
  var img = new Image();
  img.onload = function(){
    var c = document.getElementById('c');
    c.width = ${OUT_W}; c.height = ${OUT_H};
    var ctx = c.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, ${OUT_W}, ${OUT_H});
    ctx.drawImage(
      img,
      ${cropX.toFixed(1)}, ${cropY.toFixed(1)},
      ${cropW.toFixed(1)}, ${cropH.toFixed(1)},
      0, 0, ${OUT_W}, ${OUT_H}
    );
    window.ReactNativeWebView.postMessage(
      JSON.stringify({ b64: c.toDataURL('image/jpeg', 0.95).split(',')[1] })
    );
  };
  img.onerror = function(){
    window.ReactNativeWebView.postMessage(JSON.stringify({ err: 1 }));
  };
  img.src = 'data:image/jpeg;base64,${base64}';
})();
<\/script></body></html>`;
}

// ─────────────────────────────────────────────
// HIDDEN WEBVIEW CROP PROCESSOR
// ─────────────────────────────────────────────
function CropProcessor({ html, onDone }) {
  if (!html) return null;
  return (
    <WebView
      style={{ width: 1, height: 1, position: 'absolute', opacity: 0 }}
      source={{ html }}
      javaScriptEnabled
      onMessage={e => {
        try {
          const d = JSON.parse(e.nativeEvent.data);
          if (d.b64) onDone(d.b64);
        } catch (_) {}
      }}
    />
  );
}

// ─────────────────────────────────────────────
// RESULT MODAL
// ─────────────────────────────────────────────
function ResultModal({ visible, uri, onRetake, onContinue }) {
  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent>
      <View style={mStyles.backdrop}>
        <View style={mStyles.card}>

          <Text style={mStyles.title}>Photo Captured</Text>
          <Text style={mStyles.subtitle}>Review your passport photo below</Text>

          {/* Preview */}
          <View style={mStyles.previewWrap}>
            {uri
              ? <RNImage source={{ uri }} style={mStyles.preview} resizeMode="cover" />
              : <ActivityIndicator color="#fff" />
            }
            <View style={mStyles.tick}>
              <Text style={mStyles.tickTxt}>✓</Text>
            </View>
          </View>

          {/* Buttons */}
          <View style={mStyles.btnRow}>
            <TouchableOpacity style={[mStyles.btn, mStyles.btnOutline]} onPress={onRetake}>
              <Text style={[mStyles.btnTxt, { color: '#1A73E8' }]}>Retake</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[mStyles.btn, mStyles.btnSolid]} onPress={onContinue}>
              <Text style={[mStyles.btnTxt, { color: '#fff' }]}>Continue</Text>
            </TouchableOpacity>
          </View>

        </View>
      </View>
    </Modal>
  );
}

// ─────────────────────────────────────────────
// MAIN SCREEN
// ─────────────────────────────────────────────
export default function PassportPhotoScreen({ onContinue }) {
  const device    = useCameraDevice('front');
  const cameraRef = useRef(null);

  // refs — used inside interval, avoid stale closures
  const detecting    = useRef(false);   // true while a detection is running
  const detectTimer  = useRef(null);
  const latestFace   = useRef(null);    // last good face frame
  const capturing    = useRef(false);   // true while capture+crop is running

  // react state
  const [screenState, setScreenState] = useState(S.IDLE);
  const [cropHtml,    setCropHtml]    = useState(null);
  const [passUri,     setPassUri]     = useState(null);
  const [showModal,   setShowModal]   = useState(false);
  const [camReady,    setCamReady]    = useState(false);

  // camera permission on mount
  useEffect(() => {
    Camera.requestCameraPermission();
  }, []);

  // start detection loop when camera is ready
  useEffect(() => {
    if (camReady) {
      startDetectionLoop();
    }
    return () => stopDetectionLoop();
  }, [camReady]);

  // ─────────────────────────────────────────────
  // DETECTION LOOP — starts automatically
  // ─────────────────────────────────────────────
  function startDetectionLoop() {
    stopDetectionLoop();
    detectTimer.current = setInterval(detectFace, DETECT_INTERVAL_MS);
  }

  function stopDetectionLoop() {
    if (detectTimer.current) {
      clearInterval(detectTimer.current);
      detectTimer.current = null;
    }
  }

  // ─────────────────────────────────────────────
  // DETECT FACE — runs every 300ms, updates UI only
  // Does NOT capture. Just shows/hides Capture button.
  // ─────────────────────────────────────────────
  const detectFace = useCallback(async () => {
    // skip if already detecting or capturing
    if (!cameraRef.current || detecting.current || capturing.current) return;
    detecting.current = true;

    try {
      const photo = await cameraRef.current.takePhoto({ flash: 'off' });
      const path  = Platform.OS === 'android'
        ? `file://${photo.path}`
        : photo.path;

      const faces = await FaceDetection.detect(path, {
        performanceMode:    'fast',
        classificationMode: 'none',  // no eye data needed here — just detection
        landmarkMode:       'none',
        contourMode:        'none',
      });

      if (faces.length === 0) {
        latestFace.current = null;
        setScreenState(S.NO_FACE);
      } else if (faces.length > 1) {
        latestFace.current = null;
        setScreenState(S.MULTI);
      } else {
        // exactly one face — store it, show Capture button
        latestFace.current = { face: faces[0], photo, path };
        setScreenState(S.FACE_OK);
      }

    } catch (err) {
      console.warn('[Passport] detect error:', err);
    } finally {
      detecting.current = false;
    }
  }, []);

  // ─────────────────────────────────────────────
  // CAPTURE BUTTON PRESSED
  // Takes a fresh photo with the detected face & crops it
  // ─────────────────────────────────────────────
  const handleCapture = useCallback(async () => {
    if (capturing.current || !cameraRef.current) return;
    capturing.current = true;

    stopDetectionLoop();           // stop background detection
    setScreenState(S.CAPTURING);

    try {
      // Take a fresh high-quality photo
      const photo = await cameraRef.current.takePhoto({ flash: 'off' });
      const path  = Platform.OS === 'android'
        ? `file://${photo.path}`
        : photo.path;

      // Detect face in this exact frame
      const faces = await FaceDetection.detect(path, {
        performanceMode:    'accurate',
        classificationMode: 'none',
        landmarkMode:       'none',
        contourMode:        'none',
      });

      if (faces.length !== 1) {
        // face moved / disappeared at capture moment — restart detection
        capturing.current = false;
        setScreenState(faces.length === 0 ? S.NO_FACE : S.MULTI);
        startDetectionLoop();
        return;
      }

      setScreenState(S.PROCESSING);

      const imgW = photo.width  ?? 1080;
      const imgH = photo.height ?? 1440;
      const b64  = await RNFS.readFile(path, 'base64');
console.log('📸 Captured photo — running crop processor',b64);
      setCropHtml(buildCropHTML(b64, faces[0].frame, imgW, imgH));
      // capturing.current stays true until crop finishes

    } catch (err) {
      console.warn('[Passport] capture error:', err);
      capturing.current = false;
      setScreenState(S.FACE_OK);
      startDetectionLoop();
    }
  }, []);

  // ─────────────────────────────────────────────
  // CROP DONE — WebView returns base64
  // ─────────────────────────────────────────────
  const [passBase64, setPassBase64] = useState(null);
const onCropDone = useCallback(async (b64) => {
  setCropHtml(null);

  try {
    const fileName = `passport_${Date.now()}.jpg`;
    const savePath = `${RNFS.CachesDirectoryPath}/${fileName}`;

    await RNFS.writeFile(savePath, b64, 'base64');

    setPassUri(`file://${savePath}`);
    setPassBase64(b64);   // ✅ yaha store karo

    setScreenState(S.DONE);
    setShowModal(true);

  } catch (err) {
    console.warn('[Passport] save error:', err);
  } finally {
    capturing.current = false;
  }
}, []);
  // ─────────────────────────────────────────────
  // RETAKE — close modal, restart detection
  // ─────────────────────────────────────────────
  const handleRetake = useCallback(() => {
    setShowModal(false);
    setPassUri(null);
    setCropHtml(null);
    capturing.current  = false;
    detecting.current  = false;
    latestFace.current = null;
    setScreenState(S.NO_FACE);
    setTimeout(startDetectionLoop, 400);
  }, []);

  // ─────────────────────────────────────────────
  // CONTINUE — pass uri to parent
  // ─────────────────────────────────────────────
const handleContinue = useCallback(() => {
  setShowModal(false);

  const fileName = `passport_${Date.now()}.jpg`;

  if (onContinue) {
    onContinue({
      base64: passBase64,
      uri: passUri,
      name: fileName,
    });
  }

}, [passUri, passBase64, onContinue]);

  // ─────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────
  const bc           = borderColor(screenState);
  const hint         = HINT[screenState] ?? '';
  const isError      = screenState === S.NO_FACE || screenState === S.MULTI;
  const showCapture  = screenState === S.FACE_OK;
  const showSpinner  = screenState === S.CAPTURING || screenState === S.PROCESSING;

  return (
    <View style={st.root}>
      <StatusBar barStyle="light-content" backgroundColor="#000" />

      {/* Hidden WebView crop processor */}
      <CropProcessor html={cropHtml} onDone={onCropDone} />

      {/* Camera — active while modal is closed */}
      {device && !showModal && (
        <Camera
          ref={cameraRef}
          style={StyleSheet.absoluteFill}
          device={device}
          isActive
          photo
          onInitialized={() => setCamReady(true)}
        />
      )}

      {/* ── Oval guide ── */}
      <View pointerEvents="none" style={st.ovalWrap}>
        <View style={[st.oval, { borderColor: bc }]} />
      </View>

      {/* ── Top header ── */}
      <SafeAreaView style={st.header} pointerEvents="none">
        <Text style={st.headerTitle}>Take Passport Photo</Text>
        <Text style={st.headerSub}>Keep your face inside the oval</Text>
      </SafeAreaView>

      {/* ── Hint banner ── */}
      {hint !== '' && (
        <View style={st.hintWrap} pointerEvents="none">
          <View style={[st.hintBox, isError && st.hintBoxErr]}>
            <Text style={[st.hintTxt, isError && st.hintTxtErr]}>
              {hint}
            </Text>
          </View>
        </View>
      )}

      {/* ── Spinner while capturing / processing ── */}
      {showSpinner && (
        <View style={st.spinnerWrap} pointerEvents="none">
          <ActivityIndicator size="large" color="#FFD600" />
        </View>
      )}

      {/* ── Capture button — only visible when face is ready ── */}
      {showCapture && (
        <View style={st.captureWrap}>
          <TouchableOpacity style={st.captureBtn} onPress={handleCapture} activeOpacity={0.8}>
            <View style={st.captureBtnInner} />
          </TouchableOpacity>
          <Text style={st.captureLbl}>Capture</Text>
        </View>
      )}

      {/* ── Result modal ── */}
      <ResultModal
        visible={showModal}
        uri={passUri}
        onRetake={handleRetake}
        onContinue={handleContinue}
      />
    </View>
  );
}

// ─────────────────────────────────────────────
// SCREEN STYLES
// ─────────────────────────────────────────────
const st = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },

  // Oval
  ovalWrap: {
    ...StyleSheet.absoluteFillObject,
    alignItems:     'center',
    justifyContent: 'center',
  },
  oval: {
    width:        240,
    height:       310,
    borderRadius: 120,
    borderWidth:  3,
  },

  // Header
  header: {
    position:  'absolute',
    top:       0, left: 0, right: 0,
    alignItems:'center',
    paddingTop: Platform.OS === 'android' ? 44 : 52,
  },
  headerTitle: {
    color:      '#fff',
    fontSize:   19,
    fontWeight: '700',
  },
  headerSub: {
    color:    'rgba(255,255,255,0.55)',
    fontSize: 13,
    marginTop: 3,
  },

  // Hint
  hintWrap: {
    position:   'absolute',
    bottom:     155,
    left:       28,
    right:      28,
    alignItems: 'center',
  },
  hintBox: {
    backgroundColor:   'rgba(0,0,0,0.65)',
    paddingHorizontal: 20,
    paddingVertical:   10,
    borderRadius:      10,
    borderWidth:       1,
    borderColor:       'rgba(255,255,255,0.12)',
  },
  hintBoxErr: {
    borderColor:     'rgba(255,59,48,0.55)',
    backgroundColor: 'rgba(255,59,48,0.12)',
  },
  hintTxt: {
    color:     '#fff',
    fontSize:  14,
    fontWeight:'500',
    textAlign: 'center',
  },
  hintTxtErr: { color: '#FF6B6B' },

  // Spinner
  spinnerWrap: {
    ...StyleSheet.absoluteFillObject,
    alignItems:     'center',
    justifyContent: 'center',
    backgroundColor:'rgba(0,0,0,0.45)',
  },

  // Capture button — camera shutter style
  captureWrap: {
    position:       'absolute',
    bottom:         54,
    left:           0,
    right:          0,
    alignItems:     'center',
  },
  captureBtn: {
    width:           78,
    height:          78,
    borderRadius:    39,
    borderWidth:     4,
    borderColor:     '#fff',
    alignItems:      'center',
    justifyContent:  'center',
    backgroundColor: 'transparent',
  },
  captureBtnInner: {
    width:           58,
    height:          58,
    borderRadius:    29,
    backgroundColor: '#fff',
  },
  captureLbl: {
    color:     '#fff',
    fontSize:  13,
    fontWeight:'600',
    marginTop:  8,
    letterSpacing: 0.5,
  },
});

// ─────────────────────────────────────────────
// MODAL STYLES
// ─────────────────────────────────────────────
const mStyles = StyleSheet.create({
  backdrop: {
    flex:            1,
    backgroundColor: 'rgba(0,0,0,0.80)',
    alignItems:      'center',
    justifyContent:  'center',
    paddingHorizontal: 28,
  },
  card: {
    width:           '100%',
    backgroundColor: '#1C1C1E',
    borderRadius:    20,
    alignItems:      'center',
    paddingTop:      28,
    paddingBottom:   24,
    paddingHorizontal: 20,
  },
  title: {
    color:      '#fff',
    fontSize:   20,
    fontWeight: '700',
    marginBottom: 4,
  },
  subtitle: {
    color:      'rgba(255,255,255,0.50)',
    fontSize:   13,
    marginBottom: 22,
    textAlign:  'center',
  },

  // Preview container
  previewWrap: {
    position:      'relative',
    marginBottom:  24,
  },
  preview: {
    width:        OUT_W * 0.55,
    height:       OUT_H * 0.55,
    borderRadius: 10,
    backgroundColor: '#2C2C2E',
  },
  tick: {
    position:        'absolute',
    bottom:          -12,
    right:           -12,
    width:           34,
    height:          34,
    borderRadius:    17,
    backgroundColor: '#34C759',
    alignItems:      'center',
    justifyContent:  'center',
    borderWidth:     2,
    borderColor:     '#1C1C1E',
  },
  tickTxt: {
    color:      '#fff',
    fontSize:   16,
    fontWeight: '800',
  },

  // Buttons
  btnRow: {
    flexDirection: 'row',
    gap:           12,
    width:         '100%',
    marginTop:     6,
  },
  btn: {
    flex:            1,
    paddingVertical: 14,
    borderRadius:    12,
    alignItems:      'center',
  },
  btnOutline: {
    borderWidth:     1.5,
    borderColor:     '#1A73E8',
    backgroundColor: 'transparent',
  },
  btnSolid: {
    backgroundColor: '#1A73E8',
  },
  btnTxt: {
    fontSize:   15,
    fontWeight: '700',
  },
});